#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
from pathlib import Path
import xml.etree.ElementTree as xml

ROOT = Path(__file__).resolve().parents[1] / "overlay/etc/skel/.config/xfce4"


def prop(parent, name, kind="empty", value=None):
    attributes = {"name": name, "type": kind}
    if value is not None:
        attributes["value"] = str(value).lower() if isinstance(value, bool) else str(value)
    return xml.SubElement(parent, "property", attributes)


def array(parent, name, kind, values):
    node = prop(parent, name, "array")
    for value in values:
        xml.SubElement(node, "value", type=kind, value=str(value))
    return node


def channel(name):
    return xml.Element("channel", name=name, version="1.0")


def save(node):
    xml.indent(node, space="  ")
    path = ROOT / "xfconf/xfce-perchannel-xml" / (node.attrib["name"] + ".xml")
    xml.ElementTree(node).write(path, encoding="utf-8", xml_declaration=True)


panel = channel("xfce4-panel")
prop(panel, "configver", "int", 2)
p = prop(array(panel, "panels", "int", [1]), "panel-1")
prop(p, "position", "string", "p=10;x=0;y=0")
prop(p, "length", "uint", 100)
prop(p, "length-adjust", "bool", False)
prop(p, "position-locked", "bool", True)
prop(p, "size", "uint", 46)
prop(p, "icon-size", "uint", 22)
array(p, "plugin-ids", "int", range(1, 10))
plugins = prop(panel, "plugins")
for slot, name in enumerate(("launcher", "tasklist", "separator", "systray", "pulseaudio", "power-manager-plugin", "launcher", "clock", "showdesktop"), 1):
    node = prop(plugins, f"plugin-{slot}", "string", name)
    if slot in (1, 7):
        app = "relife-start.desktop" if slot == 1 else "relife-quick.desktop"
        array(node, "items", "string", [app])
    if name == "separator":
        prop(node, "expand", "bool", True)
        prop(node, "style", "uint", 0)
    if name == "clock":
        prop(node, "mode", "uint", 2)
        prop(node, "digital-format", "string", "%H:%M")
save(panel)

settings = channel("xsettings")
for group, entries in {
    "Net": {"ThemeName": ("string", "ReLife-Light"), "IconThemeName": ("string", "Adwaita")},
    "Gtk": {"FontName": ("string", "Noto Sans 10"), "CursorThemeName": ("string", "DMZ-White"), "CursorThemeSize": ("int", 24)},
}.items():
    branch = prop(settings, group)
    for key, (kind, value) in entries.items():
        prop(branch, key, kind, value)
save(settings)

wm = channel("xfwm4")
g = prop(wm, "general")
prop(g, "use_compositing", "bool", False)
prop(g, "workspace_count", "int", 1)
save(wm)

keys = channel("xfce4-keyboard-shortcuts")
custom = prop(prop(keys, "commands"), "custom")
for key, command in {"<Super>e": "thunar", "<Super>r": "relife-education-ui start", "<Super>i": "relife-education-ui settings", "<Super>a": "relife-education-ui quick"}.items():
    prop(custom, key, "string", command)
# Merge defaults supplied by Xfwm for Alt+Tab and other management shortcuts.
custom = prop(prop(keys, "xfwm4"), "custom")
prop(custom, "<Super>d", "string", "show_desktop_key")
prop(custom, "<Alt>Tab", "string", "cycle_windows_key")
prop(custom, "<Alt><Shift>Tab", "string", "cycle_reverse_windows_key")
prop(custom, "<Alt>F4", "string", "close_window_key")
save(keys)

thunar = channel("thunar")
prop(thunar, "last-location-bar", "string", "ThunarLocationEntry")
prop(thunar, "last-side-pane", "string", "ThunarShortcutsPane")
prop(thunar, "last-show-hidden", "bool", False)
save(thunar)
