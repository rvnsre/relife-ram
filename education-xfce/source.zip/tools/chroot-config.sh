#!/bin/sh
# SPDX-License-Identifier: MIT
set -eu
printf '%s\n' 'az_AZ.UTF-8 UTF-8' 'en_US.UTF-8 UTF-8' > /etc/locale.gen
locale-gen
mkdir -p /usr/lib/firefox-esr/distribution
ln -sf /etc/firefox/policies/policies.json /usr/lib/firefox-esr/distribution/policies.json
plymouth-set-default-theme relife-education
update-initramfs -u -k all
systemctl enable NetworkManager lightdm
# Default policy permits outgoing connections and drops unsolicited inbound traffic.
sed -i 's/^ENABLED=.*/ENABLED=yes/' /etc/ufw/ufw.conf
systemctl enable ufw
