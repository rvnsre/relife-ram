# Lisenziyalar

- Bu qovluqda hazırlanan ReLife UI, theme, konfiqurasiya və build skriptləri MIT lisenziyası ilə təqdim edilir. Bax `LICENSE-MIT`.
- ReLife loqosu, 10 divar kağızı və `completion.wav` bu layihə üçün orijinal yaradılıb və [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) ilə təqdim edilir. Atribut `ReLife Education`.
- Mövcud [ReLife RAM](https://github.com/rvnsre/relife-ram) layihəsindən alınan `overlay/usr/local/lib/relife`, `overlay/usr/local/bin/relife-education` və `overlay/usr/share/relife/lessons.json` faylları layihənin GPL-3.0 şərtlərinə tabedir. Bax `LICENSE-GPL-3.0`.
- Noto Sans OFL 1.1 şərtlərindədir. Arxiv həmin şriftin binarını, sistemin standart ikon və kursor aktivlərini və ya GTK-nın daxili əsas temalarını daxil etmir. Onlar Debian paketlərindən quraşdırılır və hər paket üçün `/usr/share/doc/<paket>/copyright` hökm edir. Upstream tətbiqlər müxtəlif uyğun açıq lisenziyalarla yayılır, məsələn Firefox MPL 2.0 və GTK LGPL. Paket manifesti onları eyni lisenziyaya salmır.
