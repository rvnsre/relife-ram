#!/bin/sh
# SPDX-License-Identifier: MIT
set -eu
for root in . binary; do
    config="$root/boot/grub/grub.cfg"
    [ -f "$config" ] || continue
    mkdir -p "$root/boot/grub/relife"
    cp ../chroot/usr/share/relife-education/grub-theme.txt "$root/boot/grub/relife/theme.txt"
    cp ../chroot/usr/share/backgrounds/relife-education/ufuq-dark.jpg "$root/boot/grub/relife/background.jpg"
    if ! grep -q 'relife/theme.txt' "$config"; then
        cat >> "$config" <<'GRUB'

if [ "${gfxmode}" != "" ]; then
    insmod jpeg
    set theme=/boot/grub/relife/theme.txt
    export theme
fi
GRUB
    fi
done
