# ReLife Education · XFCE

Bu paket Debian 13 üzərində orijinal təhsil masaüstünün mənbəyini, hazır aktivlərini və live-build skriptini təqdim edir.

## 1. Kimlik

Həndəsi quş qanadı emblemi və qat-qat landşaftlar ReLife kimliyini yaradır. Paneldə dərin göy-yaşıl **#132E32**, vurğuda kəhrəba **#F1B34D**, açıq səthdə **#F3F6F1**, tünd səthdə **#152829**. Tətbiq plitələri açıq rejimdə #D4EBE5, tünd rejimdə #25514F rəngindədir. Aktiv vəziyyət üçün rəngə mətn, ikon və ya alt xətt əlavə olunur.

Noto Sans 10 pt əsas, 14 pt iri mətn, 22 px pəncərə başlığı. OFL 1.1 şrifti Azərbaycan hərflərini əhatə edir. Orijinal ReLife nişanı, uyğunlaşdırılmış Adwaita sistem ikonları və 24 px DMZ-White kursoru. Yeni ikonlar üçün 24 px şəbəkə, 2 px xətt, 4 px künc. Beş orijinal motiv **Üfüq**, **Mərhələ**, **Dərələr**, **Axın**, **Açılan yol**. Hər birinin 3840×2160 ölçüdə açıq və tünd JPEG-i var. 10 fayl birlikdə təxminən 1,2 MiB tutur. Mənbələr və lisenziyalar LICENSES.md-dədir.

## 2. Ekranlar

| Ekran | Ölçü və rəng | Davranış |
|---|---|---|
| Masaüstü | 4K landşaft, GTK səthlərində 8–10 px radius | Avtomatik görünüş yerli saatla 07:00 və 19:00-da dəyişir. |
| Başla | 650×410 px başlanğıc, 18 px kənar, 16 px sütun aralığı, açıq fon #F3F6F1 | Solda axtarış və proqramlar. Sağda Təhsil mərkəzi, Fayllarım, İnternet, Mətn yaz və PDF oxu. Enter ilk nəticəni açır, Esc bağlayır. |
| Tapşırıq paneli | Tanış rejim altda 46 px, ikonlar 22 px. Minimal 40 px və ekran eninin 82%-i. | Solda ReLife və açıq proqramlar. Sağda tray, səs, enerji, sürətli parametrlər, saat və masaüstünü göstər. Klassik panel üstdədir. Minimal mərkəzdə qısa paneldir və ekran kənarına toxunur. |
| Sürətli parametrlər | 410 px başlanğıc eni, 8 px ara ilə iki sütun, sağ altda | Wi-Fi, Bluetooth meneceri, səs, parlaqlıq, gecə işığı, bildiriş ayarları. Parlaqlıq üçün uyğun backlight və cihaz icazəsi tələb olunur. |
| Fayl meneceri | Thunar yan paneli, üst ünvan sətri, GTK rəngləri | Super+E açır, Ctrl+L ünvanı seçir. Sol panel sürətli giriş üçündür. |
| Parametrlər | 650×410 px başlanğıc, 10 px ara, iki sütun | Şəbəkə, görünüş, öz hesabının şifrəsi, yenilənmə, dil/klaviatura və əlçatanlıq alətlərinə keçid. |
| Login | Mərkəzdə LightDM kartı, tünd Üfüq, Noto Sans 11 | Giriş, klaviatura/dil, sessiya, əlçatanlıq, enerji menyusu. |
| Açılış | 136×136 Plymouth nişanı, GRUB menyusu 72% en, 32 px sətir, 9 px ara | Plymouth loqosu tədricən görünür. Qrafik GRUB mövzusu mövcuddur. BIOS ISOLINUX və qrafikasız konsolda mətn fallback-ı işlədilir. |

## 3. Texniki seçim və proqramlar

**Debian 13 + XFCE/X11** mövcud ReLife bazasına uyğun gəlir, Thunar və yerli paneli təmin edir. **GTK3 CSS + Xfconf** ayrıca theme motoru tələb etmir. Qt tətbiqləri öz mövzusunda işləyir. XFWM kompozitoru seçimlidir və defolt bağlıdır. GPU blur və ekran kənarından boşluqlu floating dock bu profildə tətbiq edilməyib. Alt+Tab və Alt+Shift+Tab pəncərə dövrü, Super+D masaüstü, Super+E Thunar, Super+R Başla, Super+I parametrlər, Super+A sürətli panel. 300 ms orijinal səs Welcome-da dinlənir.

| Kateqoriya | Seçim | Təhsil səbəbi |
|---|---|---|
| Veb | Firefox ESR, AZ dili, təhsil əlfəcinləri, uBlock Origin | Dərs axtarışı və reklam/izləyici filtri. Ailə nəzarəti ayrıca siyasət tələb edir. |
| Ofis | LibreOffice Writer, Calc, Impress | DOCX, XLSX və PPTX oxuma və redaktə. Mürəkkəb makro və formatlar ayrıca yoxlanmalıdır. |
| PDF, qeydlər, arxiv | Evince, Mousepad, Xournal++, File Roller, Thunar | Tapşırıq oxumaq, mətn, əl yazısı, PDF annotasiyası və fayl saxlamaq. |
| Media və poçt | offline profili VLC və Audacious. admin profili Thunderbird. | Video dərs, audio, məktəb poçtu və təqvim. |
| Yaradıcılıq | creator profili GIMP, Inkscape, Krita, Kdenlive, OBS Studio. Core XFCE Screenshooter. | Rastr və vektor, montaj, yayım və dərs qeydi. Böyük proqramları seçmə profil ölçüyə nəzarət edir. |
| Proqramlaşdırma | offline profili Thonny və Geany | Addım-addım Python və az resursla kod yazmaq. Scratch Offline və Blockly məktəb kurikulumu üzrə əlavə inteqrasiyadır. |
| Elm və dil | Core ReLife Təhsil mərkəzi. offline profili GCompris, Anki, Stellarium və GNOME Calculator. | İnternetsiz kart, dil və astronomiya. Kalzium, PhET və GeoGebra hazır manifestdə yoxdur. GeoGebra və PhET materialları üçün konkret paylanma şərtləri yoxlanmalıdır. |
| Qrup işi | offline profili Zim. Core Xournal++. | Yerli dərs dəftəri və müəllim rəyi. |
| Mağaza və sistem | admin profili GNOME Software, Flatpak, Disk Utility, printer/scanner, OpenVPN, Timeshift. Core XFCE Task Manager və NetworkManager. | İdarəçi profili müəllim və məktəb üçündür. Flatpak üçün ayrıca mənbə, Timeshift üçün quraşdırılmış disk lazımdır. Snap seçimi quraşdırılmış sistemdə sudo apt install snapd ilə əlavə oluna bilər. |
| Təhlükəsizlik | Core UFW. admin profili ClamAV. | Gələn trafiki məhdudlaşdırmaq və faylları tələb üzrə yoxlamaq. Valideyn idarəsi məhdud şagird hesabı və ayrıca məktəb filtri tələb edir. |
| Windows uyğunluğu və kömək | Əlavə Wine və RustDesk | Wine üçün sudo apt install wine, sonra ayrıca Wine prefix-də tətbiqi sına. RustDesk rəsmi açıq buraxılışdan ayrıca quraşdırılır və uzaq sessiya təsdiqi ilə işlədilir. |

## 4. Konfiqurasiya xəritəsi

| Yol | Funksiya |
|---|---|
| overlay/etc/skel/.config/xfce4/xfconf/xfce-perchannel-xml/ | Panel, Thunar, klaviatura, şrift və kompozitor. tools/config.py XML-i yaradır. |
| overlay/etc/skel/.config/autostart/ və .xsessionrc | İlk giriş və sessiya dili. |
| overlay/usr/share/themes/ReLife-*/gtk-3.0/ | Açıq və tünd CSS. |
| overlay/usr/local/bin/relife-education-ui | Start, Sürətli parametrlər, Settings və Welcome. |
| overlay/etc/lightdm/, overlay/usr/share/plymouth/, tools/grub-live.sh | Login və boot. |
| packages/ | Core, offline, creator və admin profilləri. |

Sessiyada çağır

    relife-education-ui welcome
    relife-education-ui start
    xfconf-query -c xfce4-panel -p /panels/panel-1/position
    xfconf-query -c xfwm4 -p /general/use_compositing

## 5. ISO inteqrasiyası

Debian 13 VM-də paketləri quraşdır və yeni build qovluğu seç.

    sudo apt update
    sudo apt install live-build debootstrap xorriso squashfs-tools isolinux syslinux-common grub-pc-bin grub-efi-amd64-bin grub-common mtools dosfstools
    sudo ./build-live.sh ../relife-xfce-build
    sudo ./build-live.sh ../relife-xfce-offline-build offline

Skript overlay ağacını config/includes.chroot-a köçürür, paket siyahılarını yerləşdirir, chroot hook-da dil, Firefox, Plymouth və UFW-ni hazırlayır. Binary hook GRUB aktivlərini əlavə edir. ISO və SHA-256 yeni build qovluğunda yaranır. Bu XFCE profili əvvəlki IceWM yığımından ayrıdır. ISO quraşdırıcısız və persistence-siz live profildir. Debian Main seçilib. Qeyri-azad Wi-Fi firmware tələb edən cihaz ayrıca firmware variantına ehtiyac duya bilər.

## 6. Performans ölçməsi

**2 GiB/iki vCPU** Core üçün sınaq konfiqurasiyasıdır. İlk boş RAM hədəfi **≤750 MiB** (MemTotal − MemAvailable). Minimal profil kompozitoru bağlayır. Bu profil bütün ISO-nu RAM-a köçürmür. ISO-nun açılması, 60 saniyə boş gözləmə, Super+E, Alt+Tab, LibreOffice və Firefox bir tab ilə ayrıca vaxt və RAM qeydi tələb edir. BIOS, UEFI və köhnə Intel/HDD kompüteri ayrı ölçülməlidir. Divar kağızının kiçik JPEG ölçüsü dekod buferinin RAM xərcindən fərqlənir.

Bu çatdırılmada dörd GTK pəncərəsi virtual X ekranında açılıb. Tam ISO açılışı, 2 GiB hədəfi, fiziki Wi-Fi və backlight ölçülməyib.

## 7. Əlçatanlıq

Welcome yüksək kontrast, iri şrift və Orca işə salma seçimlərini verir. Plitələrdə yazı və fokus halqaları var. 1024×768 ekran, 200% mətn və tam klaviatura hərəkəti ayrıca yoxlanmalıdır. Orca-nın Thunar, login və əvvəlki Tk əsaslı Təhsil mərkəzi ilə işləməsi təsdiqlənməyib.

## 8. İlk giriş

Welcome-da **Dil → Görünüş → Proqramlar → Şəbəkə** bölmələri açılır. Dil seçimi növbəti girişdə sistemə tətbiq edilir. ReLife-ın öz mətnləri Azərbaycan dilindədir. Tanış, Klassik və Minimal görünüşü cari sessiyada dəyişir. Əlavə proqram qrupu düyməyə basanda və sudo icazəsi olduqda quraşdırılır. İnternetsiz istifadə üçün qrup ISO-ya əvvəlcədən daxil edilə bilər. Şəbəkə NetworkManager vasitəsilə seçilir.

## 9. Orijinallıq üzrə 10 maddəlik QA

| # | Yoxlama | Dəlil |
|---:|---|---|
| 1 | Həndəsi ReLife nişanı | tools/art.py |
| 2 | Beş motivin iki rəng variantı | 10 fayl, hər biri 3840×2160 |
| 3 | Açıq lisenziyalı şrift | Noto Sans, OFL 1.1 |
| 4 | Orijinal iki palitra | GTK3 CSS |
| 5 | Panelin aktiv vəziyyəti | Kəhrəba xətti və tətbiq adı |
| 6 | Təhsil mərkəzi və tətbiq axtarışı | GTK/Gio Start |
| 7 | Fayl meneceri və sistem ikonları | Debian Thunar və Adwaita |
| 8 | Login və boot aktivləri | ReLife PNG/JPEG və mövzu faylları |
| 9 | Qısa səs | ReLife üçün sintez edilmiş WAV |
| 10 | Aktiv və mənbələrin lisenziya izi | LICENSES.md və Debian copyright faylları |

Texniki istinadlar

- [Debian live-build](https://manpages.debian.org/trixie/live-build/lb_config.1.en.html)
- [XFCE panel](https://docs.xfce.org/xfce/xfce4-panel/start)
- [GNU GRUB mövzu formatı](https://www.gnu.org/software/grub/manual/grub/html_node/Theme-file-format.html)
- [Firefox ESR paketləri](https://packages.debian.org/search?keywords=firefox-esr&searchon=names&suite=trixie)
