#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Draw the five original landscape compositions and the desktop identity."""
import math
from pathlib import Path
import sys
from PIL import Image, ImageDraw

W, H = 3840, 2160
SCENES = [
    ("ufuq", .72, .34, 0.9, "#167b72", "#d4a25c"),
    ("merhele", .28, .28, 1.8, "#52769c", "#cd9760"),
    ("dereler", .52, .41, 2.8, "#546d83", "#bbaa61"),
    ("axin", .77, .23, 3.5, "#547a76", "#e3a383"),
    ("acilan-yol", .35, .39, 4.8, "#597387", "#e7b95a"),
]


def rgb(value):
    return tuple(bytes.fromhex(value.lstrip("#")))


def mix(a, b, factor):
    return tuple(round(x + (y - x) * factor) for x, y in zip(a, b))


def landscape(scene, dark):
    _, sx, sy, phase, accent, sun = scene
    top, base = (rgb("#101e35"), rgb("#315654")) if dark else (rgb("#cbdade"), rgb("#f3e7cf"))
    image = Image.new("RGB", (W, H))
    draw = ImageDraw.Draw(image)
    for y in range(H):
        draw.line((0, y, W, y), fill=mix(top, base, min(1, y / (H * .70))))
    x, y = W * sx, H * sy
    for radius, shade in ((208, mix(base, rgb(sun), .22)), (166, mix(base, rgb(sun), .42)), (119, rgb(sun))):
        draw.ellipse((x-radius, y-radius, x+radius, y+radius), fill=shade)
    for layer in range(6):
        ground = rgb("#071e28" if dark else "#123b43")
        colour = mix(mix(base, rgb(accent), .53 if dark else .39), ground, layer / 5)
        points = []
        for px in range(0, W + 16, 16):
            t = px / W
            wave = .066 * math.sin(t * 7.0 + phase + layer * .71)
            wave += .024 * math.cos(t * 16.0 + layer * 1.33)
            points.append((px, int(H * (.50 + .061 * layer + wave))))
        draw.polygon([*points, (W, H), (0, H)], fill=colour)
    if phase > 2.7:
        ribbon = [(int(W * (.68 + .18 * math.cos(i*.045+phase))), int(H * (.74 + i*.26/60))) for i in range(61)]
        draw.line(ribbon, fill=mix(rgb(accent), rgb(sun), .48), width=5)
    return image


def main():
    root = Path(sys.argv[1])
    art = root / "usr/share/backgrounds/relife-education"
    art.mkdir(parents=True, exist_ok=True)
    contact = Image.new("RGB", (1280, 1800), "#10282b")
    for index, scene in enumerate(SCENES):
        for dark in (False, True):
            im = landscape(scene, dark)
            label = "dark" if dark else "light"
            im.save(art / f"{scene[0]}-{label}.jpg", quality=89, optimize=True)
            im.thumbnail((640, 360))
            contact.paste(im, (640 * dark, 360 * index))
    contact.save(root.parent / "ReLife-wallpaper-preview.jpg", quality=92)
    emblem = Image.new("RGBA", (256, 256))
    draw = ImageDraw.Draw(emblem)
    draw.rounded_rectangle((4, 4, 252, 252), radius=64, fill="#14675e")
    draw.line([(57,144),(103,107),(133,133),(196,76)], fill="#faf2df", width=18, joint="curve")
    draw.line([(135,130),(143,182),(193,135),(196,76)], fill="#f4b94f", width=17, joint="curve")
    icons = root / "usr/share/icons/hicolor/256x256/apps"
    icons.mkdir(parents=True, exist_ok=True)
    emblem.save(icons / "relife-education.png")
    boot = root / "usr/share/plymouth/themes/relife-education"
    emblem.resize((136,136), Image.Resampling.LANCZOS).save(boot / "mark.png")


if __name__ == "__main__":
    main()
