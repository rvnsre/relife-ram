#!/bin/bash
# SPDX-License-Identifier: MIT
set -euo pipefail
source_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
[[ $# -ge 1 ]] || { echo "Usage: sudo $0 NEW_BUILD_DIR [offline] [creator] [admin]" >&2; exit 2; }
[[ $EUID == 0 ]] || { echo 'Run as root in a Debian 13 build VM.' >&2; exit 1; }
destination=$1
shift
for group in "$@"; do
  case "$group" in offline|creator|admin) ;; *) echo "Unknown package group: $group" >&2; exit 2 ;; esac
done
mkdir -- "$destination"
cd -- "$destination"
lb config --distribution trixie --architectures amd64 --binary-image iso-hybrid \
  --bootloaders "syslinux grub-efi" --archive-areas main --apt-recommends false \
  --debootstrap-options "--variant=minbase" --debian-installer none --memtest none \
  --uefi-secure-boot disable --iso-volume RELIFE_EDUCATION \
  --bootappend-live "boot=live components username=student hostname=relife locales=az_AZ.UTF-8 nopersistence splash quiet"
mkdir -p config/package-lists config/includes.chroot config/hooks/live
cp -a "$source_dir/overlay/." config/includes.chroot/
for group in core "$@"; do
    cp "$source_dir/packages/$group.list" "config/package-lists/$group.list.chroot"
done
install -m 755 "$source_dir/tools/chroot-config.sh" config/hooks/live/0800-relife-ui.hook.chroot
install -m 755 "$source_dir/tools/grub-live.sh" config/hooks/live/0998-relife-grub.hook.binary
lb build
sha256sum ./*.iso
